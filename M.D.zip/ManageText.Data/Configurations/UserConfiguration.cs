﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Configurations
{
    public class UserConfiguration : EntityBaseConfiguration<User>
    {
        public UserConfiguration()
        {

            Property(u => u.Username).IsRequired().HasMaxLength(100);
            Property(u => u.Email).IsRequired().HasMaxLength(100);

            Property(u => u.FirstName).IsRequired().HasMaxLength(100);
            Property(u => u.LastName).IsRequired().HasMaxLength(100);

            Property(u => u.CompanyName).IsRequired().HasMaxLength(200);
            Property(u => u.PhoneNumber).IsRequired().HasMaxLength(100);
           

            Property(u => u.CompanyName).IsRequired().HasMaxLength(1000);
            Property(u => u.Description).IsRequired().HasMaxLength(1000);
                               
          
            Property(u => u.HashedPassword).IsRequired().HasMaxLength(200);
            Property(u => u.Salt).IsRequired().HasMaxLength(200);
            Property(u => u.IsLocked).IsRequired();
            Property(u => u.DateCreated);


            Property(u => u.RegistrationDate).IsOptional();
            Property(u => u.LastLoginTime).IsOptional();

            Property(u => u.StripeCustomerId).IsOptional();
            Property(u => u.IPAddress).IsOptional();
            Property(u => u.IPAddressCountry).IsOptional();
            Property(u => u.LifetimeValue).IsOptional();
            Property(u => u.PhoneNumberConfirmed).IsOptional();
            Property(u => u.EmailConfirmed).IsOptional();
            Property(u => u.TwoFactorEnabled).IsOptional();
           


        }
    }
}
