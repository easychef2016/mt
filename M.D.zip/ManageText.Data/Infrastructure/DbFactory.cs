﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Infrastructure
{
    public class DbFactory : Disposable, IDbFactory
    {
        ManageTextContext dbContext;

        public ManageTextContext Init()
        {
            return dbContext ?? (dbContext = new ManageTextContext());
        }

        protected override void DisposeCore()
        {
            if (dbContext != null)
                dbContext.Dispose();
        }
    }
}
