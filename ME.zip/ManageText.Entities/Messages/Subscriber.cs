﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    public class Subscriber : IEntityBase, IAuditable
    {

        public Subscriber()
        {
          
            Keywords = new List<Keyword>();
        }




        public int ID { get; set; }
        public string PhoneNumber { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }

        public string AddressDetails { get; set; }
        public string StreetName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }


        public string CompanyName { get; set; }
        public string Comments { get; set; }

        public bool Subscribed { get; set; }
        public DateTime SubscribedAt { get; set; }

        public bool Disabled { get; set; }
        public DateTime DisabledAt { get; set; }


                     
        
        public virtual ICollection<Keyword> Keywords { get; set; }



        //  Customer Id details 
        public int UserId { get; set; }
        public virtual User User { get; set; }



        //Audit Columns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }






        //Abu:Ref Relatiionship
        // Configure Student & StudentAddress entity
        // modelBuilder.Entity<Student>()
        //         .HasOptional(s => s.Address) // Mark Address property optional in Student entity
        //         .WithRequired(ad => ad.Student); // mark Student property as required in StudentAddress entity. Cannot save StudentAddress without Student
    }

}

