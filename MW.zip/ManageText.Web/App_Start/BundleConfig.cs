﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManageText.Web.App_Start
{
    public class BundleConfig
    {
    }
}